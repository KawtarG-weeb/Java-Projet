package ma.emsi.productshopping.service;

import ma.emsi.productshopping.dao.OrderDAO;
import ma.emsi.productshopping.dao.ProductDAO;
import ma.emsi.productshopping.dao.UserDAO;
import ma.emsi.productshopping.model.Order;
import ma.emsi.productshopping.model.Product;
import ma.emsi.productshopping.model.User;
import java.util.List;

public class OrderService {
    private final OrderDAO orderDAO;
    private final ProductDAO productDAO;
    private final UserDAO userDAO;

    public OrderService() {
        this.orderDAO = new OrderDAO();
        this.productDAO = new ProductDAO();
        this.userDAO = new UserDAO();
    }

    public Order createOrder(Long userId, Product product, int quantity) {
        User user = userDAO.findById(userId);
        if (user != null && product != null) {
            // Check stock
            if (product.getStock() >= quantity) {
                // Update stock
                product.setStock(product.getStock() - quantity);
                productDAO.update(product);

                // Create Order
                Double totalAmount = product.getPrice() * quantity;
                Order order = new Order(user, product, totalAmount, "PENDING");
                orderDAO.save(order);
                return order; // Return the created order
            }
        }
        return null; // Return null if stock insufficient or user/product not found
    }

    public List<Order> getUserOrders(Long userId) {
        return orderDAO.findByUser(userId);
    }

    public List<Order> getAllOrders() {
        return orderDAO.findAll();
    }

    public void updateOrderStatus(Long orderId, String status) {
        Order order = orderDAO.findById(orderId);
        if (order != null) {
            order.setStatus(status);
            orderDAO.update(order);
        }
    }
}
