package ma.emsi.productshopping.service;

import ma.emsi.productshopping.dao.OrderDAO;
import ma.emsi.productshopping.dao.PaymentDAO;
import ma.emsi.productshopping.model.Order;
import ma.emsi.productshopping.model.Payment;

public class PaymentService {
    private final PaymentDAO paymentDAO;
    private final OrderDAO orderDAO;

    public PaymentService() {
        this.paymentDAO = new PaymentDAO();
        this.orderDAO = new OrderDAO();
    }

    public boolean processPayment(Long orderId, Double amount) {
        Order order = orderDAO.findById(orderId);
        if (order != null) {
            // Simulate payment logic (e.g., check if amount matches)
            if (amount >= order.getTotalAmount()) {
                Payment payment = new Payment(order, amount, "SUCCESS", "SIMULATED");
                paymentDAO.save(payment);

                order.setStatus("PAID");
                orderDAO.update(order);
                return true;
            } else {
                Payment payment = new Payment(order, amount, "FAILED", "SIMULATED");
                paymentDAO.save(payment);
                return false;
            }
        }
        return false;
    }
}
