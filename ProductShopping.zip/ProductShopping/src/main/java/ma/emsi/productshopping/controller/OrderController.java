package ma.emsi.productshopping.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.emsi.productshopping.HelloApplication;
import ma.emsi.productshopping.model.Order;
import ma.emsi.productshopping.model.User;
import ma.emsi.productshopping.service.OrderService;
import ma.emsi.productshopping.util.UserSession;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class OrderController {

    @FXML
    private TableView<Order> orderTable;

    @FXML
    private TableColumn<Order, Long> idColumn;

    @FXML
    private TableColumn<Order, String> productColumn;

    @FXML
    private TableColumn<Order, Double> amountColumn;

    @FXML
    private TableColumn<Order, String> dateColumn;

    @FXML
    private TableColumn<Order, String> statusColumn;

    private final OrderService orderService;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public OrderController() {
        this.orderService = new OrderService();
    }

    @FXML
    public void initialize() {
        if (orderTable == null)
            return;

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productColumn
                .setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getProduct().getName()));
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        dateColumn.setCellValueFactory(
                cellData -> new SimpleStringProperty(cellData.getValue().getOrderDate().format(formatter)));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        loadUserOrders();
    }

    private void loadUserOrders() {
        User currentUser = UserSession.getInstance().getCurrentUser();
        if (currentUser != null) {
            List<Order> orders = orderService.getUserOrders(currentUser.getId());
            ObservableList<Order> observableOrders = FXCollections.observableArrayList(orders);
            orderTable.setItems(observableOrders);
        }
    }

    @FXML
    private void onBackButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("view/ProductListView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) orderTable.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
