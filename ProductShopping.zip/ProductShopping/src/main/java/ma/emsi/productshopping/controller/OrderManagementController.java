package ma.emsi.productshopping.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import ma.emsi.productshopping.model.Order;
import ma.emsi.productshopping.service.OrderService;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class OrderManagementController {

    @FXML
    private TableView<Order> orderTable;

    @FXML
    private TableColumn<Order, Long> idColumn;

    @FXML
    private TableColumn<Order, String> userColumn;

    @FXML
    private TableColumn<Order, String> productColumn;

    @FXML
    private TableColumn<Order, Double> amountColumn;

    @FXML
    private TableColumn<Order, String> dateColumn;

    @FXML
    private TableColumn<Order, String> statusColumn;

    private final OrderService orderService;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public OrderManagementController() {
        this.orderService = new OrderService();
    }

    @FXML
    public void initialize() {
        if (orderTable == null)
            return;

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        userColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getUser().getName()));
        productColumn
                .setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getProduct().getName()));
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        dateColumn.setCellValueFactory(
                cellData -> new SimpleStringProperty(cellData.getValue().getOrderDate().format(formatter)));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        loadOrders();
    }

    private void loadOrders() {
        List<Order> orders = orderService.getAllOrders();
        ObservableList<Order> observableOrders = FXCollections.observableArrayList(orders);
        orderTable.setItems(observableOrders);
    }
}
