package ma.emsi.productshopping.util;

import ma.emsi.productshopping.dao.CategoryDAO;
import ma.emsi.productshopping.dao.ProductDAO;
import ma.emsi.productshopping.dao.UserDAO;
import ma.emsi.productshopping.model.Category;
import ma.emsi.productshopping.model.Product;
import ma.emsi.productshopping.model.User;

public class DataSeeder {

    public static void seed() {
        UserDAO userDAO = new UserDAO();
        if (userDAO.findByEmail("admin@test.com") == null) {
            User admin = new User("Admin", "admin@test.com", "admin123", "ADMIN");
            userDAO.save(admin);
            System.out.println("Seeded Admin user.");
        }

        if (userDAO.findByEmail("client@test.com") == null) {
            User client = new User("Client", "client@test.com", "client123", "CLIENT");
            userDAO.save(client);
            System.out.println("Seeded Client user.");
        }

        CategoryDAO categoryDAO = new CategoryDAO();
        if (categoryDAO.findAll().isEmpty()) {
            Category c1 = new Category("Nettoyants");
            categoryDAO.save(c1);
            Category c2 = new Category("Sérums");
            categoryDAO.save(c2);
            Category c3 = new Category("Crèmes");
            categoryDAO.save(c3);

            ProductDAO productDAO = new ProductDAO();
            // Using placeholder image paths - in a real app these would be URLs or local
            // paths
            productDAO.save(new Product("Gel Nettoyant", "Gentle cleanser", 15.0, 50, c1,
                    "https://via.placeholder.com/150?text=Gel+Nettoyant"));
            productDAO.save(new Product("Vitamin C Serum", "Brightening serum", 35.0, 30, c2,
                    "https://via.placeholder.com/150?text=Vitamin+C"));
            productDAO.save(new Product("Moisturizer", "Hydrating cream", 25.0, 40, c3,
                    "https://via.placeholder.com/150?text=Moisturizer"));
            System.out.println("Seeded Products and Categories.");
        }
    }
}
