package ma.emsi.productshopping;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        System.out.println("==========================================");
        System.out.println("=== VERIFIED VERSION: ALL FEATURES ACTIVE ===");
        System.out.println("=== ADMIN LOGIN: admin@test.com / admin123 ===");
        System.out.println("=== CLIENT LOGIN: client@test.com / client123 ===");
        System.out.println("==========================================");
        ma.emsi.productshopping.util.DataSeeder.seed();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("view/LoginView.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setTitle("Product Shopping - Login");
        stage.setScene(scene);
        stage.show();
    }
}
