package ma.emsi.productshopping.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import ma.emsi.productshopping.HelloApplication;
import ma.emsi.productshopping.model.Category;
import ma.emsi.productshopping.model.Product;
import ma.emsi.productshopping.service.ProductService;
import java.io.IOException;
import java.util.List;
import javafx.scene.control.Alert;
import ma.emsi.productshopping.model.Order;
import ma.emsi.productshopping.model.User;
import ma.emsi.productshopping.service.OrderService;
import ma.emsi.productshopping.service.PaymentService;
import ma.emsi.productshopping.util.UserSession;

public class ProductController {

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private GridPane productGrid;

    @FXML
    private VBox categoryBox;

    private final ProductService productService;
    private final OrderService orderService;
    private final PaymentService paymentService;

    public ProductController() {
        this.productService = new ProductService();
        this.orderService = new OrderService();
        this.paymentService = new PaymentService();
    }

    @FXML
    public void initialize() {
        if (productGrid == null)
            return;

        loadCategories();
        loadProducts(null); // Load all by default
    }

    private void loadCategories() {
        if (categoryBox == null)
            return;

        categoryBox.getChildren().clear();
        Button allBtn = new Button("All Products");
        allBtn.getStyleClass().add("category-button");
        allBtn.setMaxWidth(Double.MAX_VALUE);
        allBtn.setOnAction(e -> loadProducts(null));
        categoryBox.getChildren().add(allBtn);

        List<Category> categories = productService.getAllCategories();
        for (Category cat : categories) {
            Button catBtn = new Button(cat.getName());
            catBtn.getStyleClass().add("category-button");
            catBtn.setMaxWidth(Double.MAX_VALUE);
            catBtn.setOnAction(e -> loadProducts(cat.getId()));
            categoryBox.getChildren().add(catBtn);
        }
    }

    private void loadProducts(Long categoryId) {
        productGrid.getChildren().clear();
        // Re-add header
        Label header = new Label(categoryId == null ? "All Products" : "Filtered Products");
        header.getStyleClass().add("header-label");
        productGrid.add(header, 0, 0, 3, 1);

        List<Product> products = productService.getProductsByCategory(categoryId);
        int column = 0;
        int row = 1;

        for (Product product : products) {
            try {
                VBox productBox = createProductBox(product);
                productGrid.add(productBox, column++, row);

                if (column == 3) {
                    column = 0;
                    row++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private VBox createProductBox(Product product) {
        VBox box = new VBox();
        box.getStyleClass().add("product-card");
        box.setSpacing(10);
        box.setPrefWidth(220);

        // Image
        ImageView imageView = new ImageView();
        try {
            String imagePath = product.getImagePath();
            if (imagePath != null && (imagePath.startsWith("http") || imagePath.startsWith("file:"))) {
                imageView.setImage(new Image(imagePath));
            } else {
                imageView.setImage(
                        new Image("https://via.placeholder.com/200?text=" + product.getName().replace(" ", "+")));
            }
        } catch (Exception e) {
        }
        imageView.setFitHeight(150);
        imageView.setFitWidth(180);
        imageView.setPreserveRatio(true);

        Label nameLabel = new Label(product.getName());
        nameLabel.getStyleClass().add("product-name");

        Label priceLabel = new Label("$" + product.getPrice());
        priceLabel.getStyleClass().add("product-price");

        Label stockLabel = new Label(product.getStock() > 0 ? "In Stock: " + product.getStock() : "Out of Stock");
        stockLabel.getStyleClass().add("stock-label");
        stockLabel.setStyle(product.getStock() > 0 ? "-fx-text-fill: green;" : "-fx-text-fill: red;");

        Button buyButton = new Button("Buy Now");
        buyButton.getStyleClass().add("primary-button");
        buyButton.setDisable(product.getStock() <= 0);
        buyButton.setOnAction(e -> showPaymentViewForProduct(product));

        box.getChildren().addAll(imageView, nameLabel, priceLabel, stockLabel, buyButton);
        return box;
    }

    private void showPaymentViewForProduct(Product product) {
        User currentUser = UserSession.getInstance().getCurrentUser();
        if (currentUser == null) {
            showAlert(Alert.AlertType.ERROR, "Login Required", "You must be logged in to buy products.");
            return;
        }

        Order order = orderService.createOrder(currentUser.getId(), product, 1);
        if (order != null) {
            boolean paymentSuccess = paymentService.processPayment(order.getId(), product.getPrice());
            if (paymentSuccess) {
                showAlert(Alert.AlertType.INFORMATION, "Order Successful",
                        "Order #" + order.getId() + " Placed!\n" +
                                "Product: " + product.getName() + "\n" +
                                "Amount: $" + product.getPrice() + "\n" +
                                "Status: PAID (Simulated)");
                // Refresh to show updated stock
                loadProducts(null);
            } else {
                showAlert(Alert.AlertType.ERROR, "Payment Failed", "Payment processing failed.");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Order Failed", "Could not place order. Out of stock?");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    private void onMyOrdersButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("view/OrderView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) productGrid.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onLogoutButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("view/LoginView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) productGrid.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
