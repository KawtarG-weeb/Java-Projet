package ma.emsi.productshopping.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import ma.emsi.productshopping.model.Category;
import ma.emsi.productshopping.service.ProductService;

public class CategoryManagementController {

    @FXML private TableView<Category> categoryTable;
    @FXML private TableColumn<Category, Long> idColumn;
    @FXML private TableColumn<Category, String> nameColumn;
    
    @FXML private TextField nameField;

    private final ProductService productService;

    public CategoryManagementController() {
        this.productService = new ProductService();
    }

    @FXML
    public void initialize() {
        if (categoryTable == null) return;

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        loadCategories();
        
        categoryTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                nameField.setText(newSelection.getName());
            }
        });
    }

    private void loadCategories() {
        categoryTable.setItems(FXCollections.observableArrayList(productService.getAllCategories()));
    }

    @FXML
    private void onAddButtonClick() {
        String name = nameField.getText();
        if (name == null || name.trim().isEmpty()) {
            showAlert("Error", "Please enter a category name");
            return;
        }

        productService.addCategory(name);
        loadCategories();
        clearForm();
    }

    @FXML
    private void onUpdateButtonClick() {
        Category selected = categoryTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Error", "No category selected");
            return;
        }

        String name = nameField.getText();
        if (name == null || name.trim().isEmpty()) {
            showAlert("Error", "Please enter a category name");
            return;
        }

        productService.updateCategory(selected.getId(), name);
        loadCategories();
        clearForm();
    }

    @FXML
    private void onDeleteButtonClick() {
        Category selected = categoryTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            productService.deleteCategory(selected.getId());
            loadCategories();
            clearForm();
        } else {
            showAlert("Error", "No category selected");
        }
    }
    
    @FXML
    private void onClearButtonClick() {
        clearForm();
    }

    private void clearForm() {
        nameField.clear();
        categoryTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
