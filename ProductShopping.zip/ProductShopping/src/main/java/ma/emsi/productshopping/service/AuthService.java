package ma.emsi.productshopping.service;

import ma.emsi.productshopping.dao.UserDAO;
import ma.emsi.productshopping.model.User;

public class AuthService {
    private final UserDAO userDAO;

    public AuthService() {
        this.userDAO = new UserDAO();
    }

    public User login(String email, String password) {
        User user = userDAO.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public void register(String name, String email, String password, String role) {
        User user = new User(name, email, password, role);
        userDAO.save(user);
    }
}
