package ma.emsi.productshopping.service;

import ma.emsi.productshopping.dao.CategoryDAO;
import ma.emsi.productshopping.dao.ProductDAO;
import ma.emsi.productshopping.model.Category;
import ma.emsi.productshopping.model.Product;
import java.util.List;

public class ProductService {
    private final ProductDAO productDAO;
    private final CategoryDAO categoryDAO;

    public ProductService() {
        this.productDAO = new ProductDAO();
        this.categoryDAO = new CategoryDAO();
    }

    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    public List<Product> getProductsByCategory(Long categoryId) {
        if (categoryId == null) {
            return getAllProducts();
        }
        return productDAO.findByCategory(categoryId);
    }

    public List<Category> getAllCategories() {
        return categoryDAO.findAll();
    }

    public void addProduct(String name, String description, Double price, Integer stock, Long categoryId,
            String imagePath) {
        Category category = categoryDAO.findById(categoryId);
        if (category != null) {
            Product product = new Product(name, description, price, stock, category, imagePath);
            productDAO.save(product);
        }
    }

    public void updateProduct(Long id, String name, String description, Double price, Integer stock, Long categoryId,
            String imagePath) {
        Product product = productDAO.findById(id);
        Category category = categoryDAO.findById(categoryId);
        if (product != null && category != null) {
            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setStock(stock);
            product.setCategory(category);
            product.setImagePath(imagePath);
            productDAO.update(product);
        }
    }

    public void deleteProduct(Long id) {
        productDAO.delete(id);
    }

    // Category management methods for Admin
    public void addCategory(String name) {
        Category category = new Category(name);
        categoryDAO.save(category);
    }

    public void updateCategory(Long id, String name) {
        Category category = categoryDAO.findById(id);
        if (category != null) {
            category.setName(name);
            categoryDAO.update(category);
        }
    }

    public void deleteCategory(Long id) {
        categoryDAO.delete(id);
    }
}
