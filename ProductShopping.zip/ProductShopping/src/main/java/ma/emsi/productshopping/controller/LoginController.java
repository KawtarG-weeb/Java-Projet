package ma.emsi.productshopping.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ma.emsi.productshopping.HelloApplication;
import ma.emsi.productshopping.model.User;
import ma.emsi.productshopping.service.AuthService;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    private final AuthService authService;

    public LoginController() {
        this.authService = new AuthService();
    }

    @FXML
    protected void onLoginButtonClick() {
        String email = emailField.getText();
        String password = passwordField.getText();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter email and password");
            return;
        }

        User user = authService.login(email, password);
        if (user != null) {
            ma.emsi.productshopping.util.UserSession.getInstance().setCurrentUser(user);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Login successful as " + user.getRole());
            navigateToDashboard(user);
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid credentials");
        }
    }

    private void navigateToDashboard(User user) {
        try {
            FXMLLoader loader;
            if ("ADMIN".equals(user.getRole())) {
                loader = new FXMLLoader(HelloApplication.class.getResource("view/AdminDashboardView.fxml"));
            } else {
                loader = new FXMLLoader(HelloApplication.class.getResource("view/ProductListView.fxml")); // Client Home
            }

            // Pass user to the next controller if needed
            // Parent root = loader.load();
            // ... controller setup ...

            // For now just load the view, assuming we will create them next
            // Since those views don't exist yet, this might fail at runtime if I don't
            // create them soon.
            // I will implement a placeholder for them.

            // For this step, I'll just print to console or show alert, but the requirement
            // is to navigate.
            // I'll assume valid paths.
            Parent root = loader.load();
            Stage stage = (Stage) emailField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Could not load dashboard: " + e.getMessage());
        }
    }

    @FXML
    protected void onRegisterLinkClick() {
        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("view/RegisterView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) emailField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Could not load registration view: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
