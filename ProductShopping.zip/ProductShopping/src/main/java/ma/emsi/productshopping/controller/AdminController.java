package ma.emsi.productshopping.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import ma.emsi.productshopping.HelloApplication;
import ma.emsi.productshopping.util.UserSession;
import java.io.IOException;

public class AdminController {

    @FXML
    private StackPane contentArea;

    @FXML
    public void initialize() {
        // Load default view if needed, or just show welcome
    }

    @FXML
    private void onManageProductsClick() {
        loadView("view/ProductManagementView.fxml");
    }

    @FXML
    private void onManageCategoriesClick() {
        loadView("view/CategoryManagementView.fxml");
    }

    @FXML
    private void onViewOrdersClick() {
        loadView("view/OrderManagementView.fxml");
    }

    private void loadView(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource(fxmlPath));
            Parent view = loader.load();
            contentArea.getChildren().clear();
            contentArea.getChildren().add(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onLogoutButtonClick() {
        UserSession.getInstance().logout();
        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("view/LoginView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) contentArea.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
