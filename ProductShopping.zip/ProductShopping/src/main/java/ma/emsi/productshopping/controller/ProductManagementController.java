package ma.emsi.productshopping.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import ma.emsi.productshopping.model.Category;
import ma.emsi.productshopping.model.Product;
import ma.emsi.productshopping.service.ProductService;
import java.util.List;

public class ProductManagementController {

    @FXML
    private TableView<Product> productTable;
    @FXML
    private TableColumn<Product, Long> idColumn;
    @FXML
    private TableColumn<Product, String> nameColumn;
    @FXML
    private TableColumn<Product, Double> priceColumn;
    @FXML
    private TableColumn<Product, Integer> stockColumn;
    @FXML
    private TableColumn<Product, String> categoryColumn;

    @FXML
    private TextField nameField;
    @FXML
    private TextField descriptionField;
    @FXML
    private TextField priceField;
    @FXML
    private TextField stockField;
    @FXML
    private TextField imageField;
    @FXML
    private ComboBox<Category> categoryComboBox;

    private final ProductService productService;

    public ProductManagementController() {
        this.productService = new ProductService();
    }

    @FXML
    public void initialize() {
        if (productTable == null)
            return;

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        stockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        categoryColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().getCategory().getName()));

        loadCategories();
        loadProducts();

        productTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateForm(newSelection);
            }
        });
    }

    private void loadCategories() {
        List<Category> categories = productService.getAllCategories();
        categoryComboBox.setItems(FXCollections.observableArrayList(categories));
        // Setup converter to display name
        categoryComboBox.setConverter(new javafx.util.StringConverter<Category>() {
            @Override
            public String toString(Category object) {
                return object == null ? "" : object.getName();
            }

            @Override
            public Category fromString(String string) {
                return null; // Not needed
            }
        });
    }

    private void loadProducts() {
        productTable.setItems(FXCollections.observableArrayList(productService.getAllProducts()));
    }

    private void populateForm(Product product) {
        nameField.setText(product.getName());
        descriptionField.setText(product.getDescription());
        priceField.setText(String.valueOf(product.getPrice()));
        stockField.setText(String.valueOf(product.getStock()));
        imageField.setText(product.getImagePath());

        // Find matching category in combobox
        for (Category cat : categoryComboBox.getItems()) {
            if (cat.getId().equals(product.getCategory().getId())) {
                categoryComboBox.setValue(cat);
                break;
            }
        }
    }

    @FXML
    private void onAddButtonClick() {
        try {
            String name = nameField.getText();
            String desc = descriptionField.getText();
            Double price = Double.parseDouble(priceField.getText());
            Integer stock = Integer.parseInt(stockField.getText());
            Category cat = categoryComboBox.getValue();
            String img = imageField.getText();

            if (cat == null) {
                showAlert("Error", "Please select a category");
                return;
            }

            productService.addProduct(name, desc, price, stock, cat.getId(), img);
            loadProducts();
            clearForm();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid price or stock format");
        }
    }

    @FXML
    private void onUpdateButtonClick() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Error", "No product selected");
            return;
        }

        try {
            String name = nameField.getText();
            String desc = descriptionField.getText();
            Double price = Double.parseDouble(priceField.getText());
            Integer stock = Integer.parseInt(stockField.getText());
            Category cat = categoryComboBox.getValue();
            String img = imageField.getText();

            productService.updateProduct(selected.getId(), name, desc, price, stock, cat.getId(), img);
            loadProducts();
            clearForm();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid price or stock format");
        }
    }

    @FXML
    private void onDeleteButtonClick() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            productService.deleteProduct(selected.getId());
            loadProducts();
            clearForm();
        }
    }

    @FXML
    private void onClearButtonClick() {
        clearForm();
    }

    private void clearForm() {
        nameField.clear();
        descriptionField.clear();
        priceField.clear();
        stockField.clear();
        imageField.clear();
        categoryComboBox.setValue(null);
        productTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
