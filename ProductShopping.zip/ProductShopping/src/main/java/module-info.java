module ma.emsi.productshopping {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;

    requires java.sql;
    requires java.naming;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;

    opens ma.emsi.productshopping to javafx.fxml;

    exports ma.emsi.productshopping;

    exports ma.emsi.productshopping.controller;

    opens ma.emsi.productshopping.controller to javafx.fxml;

    exports ma.emsi.productshopping.model;

    opens ma.emsi.productshopping.model to org.hibernate.orm.core, javafx.base;
}